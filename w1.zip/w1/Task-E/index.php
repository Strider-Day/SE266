<?php

$task = [
    "title" => "Homework",
    "due" => "tonight",
    "assigned_to" => "Andrew",
    "completed" => TRUE,

];

require "index_view.php";