<?php

//array with a key and a value 
$task = [
    "title" => "Homework",
    "due" => "tonight",
    "assigned_to" => "Andrew",
    "completed" => "yes",

];

require "index_view.php";