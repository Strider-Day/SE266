<?php

//making a simple array
$animals = [
    "dog",
    "cat",
    "mouse",
    "bird",
    "fish",
];

//referring to the index view.php file
require "index_view.php";